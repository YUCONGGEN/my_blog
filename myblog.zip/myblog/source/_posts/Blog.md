---
abbrlink: '0'
---
---
title: 个人博客搭建
author: 郁
coverImg: /medias/banner/6.jpg
top: true
cover: true
toc: true
mathjax: false
summary: >-
  前前后后大概花了2周的时间，目前个人博客已经完善的差不多了，现在写个文章做个阶段总结，后续如果有更新的地方，会及时补充。本博客基于Hexo框架，采用hexo-theme-matery主题，并在此基础上做了改进。
tags:
  - Hexo
  - Github
  - 博客
categories:
  - 博客篇
abbrlink: e3e08109
date: 2019-08-27 11:41:03
img:
password:
reprintPolicy: cc_by
